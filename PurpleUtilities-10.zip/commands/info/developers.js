const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const { Color } = require("../../config.js");

module.exports = {
  name: "developers",
  aliases: [],
  description: "The developers of Purple Utilities",
  usage: "Developers",
  run: async (client, message, args) => {
    //Start
    message.delete();

    const embed = new MessageEmbed()
      .setColor(Color)
      .setTitle('Developers')
      .setDescription(`LISPlaysYT#3444\nMiniLoot#1230\nJPKB#5846`)
      .setTimestamp();

    message.channel.send(embed);

    //End
  }
};
