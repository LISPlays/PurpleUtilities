const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const { Color } = require("../../config.js");

module.exports = {
  name: "test",
  aliases: [],
  description: "test for Purple Utilities",
  usage: "Test",
  run: async (client, message, args) => {
    //Start
    message.delete();
    let Member =
      message.mentions.members.first() ||
      message.guild.members.cache.get(args[0]) ||
      message.member;

    let Result = Math.floor(Math.random() * 101);

    let embed = new MessageEmbed()
      .setColor(Color)
      .setTitle(``)
      .setDescription({"votes":[{"user":"724858864545169439","current":1673148961933,"next":1673192161933}]})
      .setTimestamp();

    message.channel.send(embed);

    //End
  }
};