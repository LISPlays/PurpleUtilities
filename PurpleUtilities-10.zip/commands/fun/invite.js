const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const { Color } = require("../../config.js");

module.exports = {
  name: "invite",
  aliases: [],
  description: "Pong!",
  usage: "Invite",
  run: async (client, message, args) => {
    //Start
    message.delete();

    const embed = new MessageEmbed()
      .setColor(Color)
      .setDescription(`To invite Purple Utilities click [here](https://discord.com/api/oauth2/authorize?client_id=833876771949903922&permissions=8&scope=bot)`)
      .setFooter(`Requested By ${message.author.username}`)
      .setTimestamp();

    message.channel.send(embed);

    //End
  }
};
