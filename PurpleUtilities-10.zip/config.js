exports.Prefix = `;`;
exports.Token = ``;
exports.Color = `#A020F0`;
exports.Port = `8080`;
exports.BotName= `Purple Utilities`;